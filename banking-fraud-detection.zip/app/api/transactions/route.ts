import { type NextRequest, NextResponse } from "next/server"

// Mock transaction data
const transactions = [
  {
    id: "1",
    userId: "john_doe",
    amount: 250.0,
    merchant: "Amazon",
    timestamp: "2024-01-07T14:30:00Z",
    status: "normal",
    riskScore: 0.2,
    blockchainHash: "0x1a2b3c4d5e6f7890abcdef1234567890",
  },
  {
    id: "2",
    userId: "john_doe",
    amount: 1500.0,
    merchant: "Unknown Merchant",
    timestamp: "2024-01-07T02:15:00Z",
    status: "flagged",
    riskScore: 0.8,
    blockchainHash: "0x2b3c4d5e6f7890abcdef1234567890ab",
  },
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const userId = searchParams.get("userId")

  // In real app, this would query your Java backend and blockchain
  const userTransactions = userId ? transactions.filter((t) => t.userId === userId) : transactions

  return NextResponse.json({
    success: true,
    transactions: userTransactions,
  })
}

export async function POST(request: NextRequest) {
  try {
    const transactionData = await request.json()

    // In real app, this would:
    // 1. Send to Java backend for processing
    // 2. Run through ML fraud detection
    // 3. Log to blockchain
    // 4. Return result

    const newTransaction = {
      id: Date.now().toString(),
      ...transactionData,
      timestamp: new Date().toISOString(),
      blockchainHash: `0x${Math.random().toString(16).substr(2, 32)}`,
    }

    return NextResponse.json({
      success: true,
      transaction: newTransaction,
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Transaction processing failed" }, { status: 500 })
  }
}
