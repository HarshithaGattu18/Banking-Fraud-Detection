import { type NextRequest, NextResponse } from "next/server"

// Mock user database - in real app, this would be in your Java backend
const users = [
  // Admin users
  { username: "admin", password: "admin123", role: "admin" },
  { username: "superadmin", password: "super123", role: "admin" },

  // Analyst users
  { username: "analyst", password: "analyst123", role: "analyst" },
  { username: "data_analyst", password: "analyst456", role: "analyst" },

  // Regular users
  { username: "user", password: "user123", role: "user" },
  { username: "john_doe", password: "password", role: "user" },
  { username: "jane_smith", password: "password", role: "user" },
  { username: "demo_user", password: "demo123", role: "user" },

  // Test users
  { username: "test", password: "test", role: "user" },
  { username: "demo", password: "demo", role: "user" },
]

export async function POST(request: NextRequest) {
  try {
    const { username, password, role } = await request.json()

    // In a real application, this would make a request to your Java backend
    // Example: const response = await fetch('http://localhost:8080/api/auth/login', {...})

    // Mock authentication
    const user = users.find((u) => u.username === username && u.password === password && u.role === role)

    if (user) {
      // Generate a mock JWT token (in real app, this comes from Java backend)
      const token = `mock-jwt-token-${Date.now()}`

      return NextResponse.json({
        success: true,
        token,
        user: {
          username: user.username,
          role: user.role,
        },
      })
    } else {
      return NextResponse.json({ success: false, message: "Invalid credentials" }, { status: 401 })
    }
  } catch (error) {
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}
