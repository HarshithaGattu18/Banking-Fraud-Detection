import { type NextRequest, NextResponse } from "next/server"

// Mock blockchain data
const blockchainLogs = [
  {
    blockNumber: 1234567,
    blockHash: "0x1a2b3c4d5e6f7890abcdef1234567890",
    timestamp: "2024-01-07T14:30:45Z",
    transactions: 15,
    gasUsed: 315000,
    status: "confirmed",
  },
  {
    blockNumber: 1234566,
    blockHash: "0x2b3c4d5e6f7890abcdef1234567890ab",
    timestamp: "2024-01-07T14:15:30Z",
    transactions: 12,
    gasUsed: 252000,
    status: "confirmed",
  },
]

const smartContracts = [
  {
    name: "FraudDetection",
    address: "0xabcdef1234567890abcdef1234567890abcdef12",
    status: "deployed",
    version: "1.2.0",
  },
  {
    name: "UserAuthentication",
    address: "0xbcdef1234567890abcdef1234567890abcdef123",
    status: "deployed",
    version: "1.0.0",
  },
  {
    name: "TransactionLogger",
    address: "0xcdef1234567890abcdef1234567890abcdef1234",
    status: "deployed",
    version: "1.1.0",
  },
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const type = searchParams.get("type")

  if (type === "contracts") {
    return NextResponse.json({
      success: true,
      contracts: smartContracts,
    })
  }

  return NextResponse.json({
    success: true,
    blocks: blockchainLogs,
    networkStatus: {
      nodesConnected: 12,
      networkHealth: "healthy",
      lastBlockTime: "2024-01-07T14:30:45Z",
    },
  })
}
