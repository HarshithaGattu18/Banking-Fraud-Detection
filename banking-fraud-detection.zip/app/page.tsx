"use client"

import { useState } from "react"
import { LoginForm } from "@/components/login-form"
import { UserDashboard } from "@/components/dashboards/user-dashboard"
import { AdminDashboard } from "@/components/dashboards/admin-dashboard"
import { AnalystDashboard } from "@/components/dashboards/analyst-dashboard"

export type UserRole = "user" | "admin" | "analyst"

export interface User {
  username: string
  role: UserRole
  token?: string
}

export default function Home() {
  const [user, setUser] = useState<User | null>(null)

  const handleLogin = (userData: User) => {
    setUser(userData)
  }

  const handleLogout = () => {
    setUser(null)
  }

  if (!user) {
    return <LoginForm onLogin={handleLogin} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-r from-slate-900 to-slate-700">
      {user.role === "user" && <UserDashboard user={user} onLogout={handleLogout} />}
      {user.role === "admin" && <AdminDashboard user={user} onLogout={handleLogout} />}
      {user.role === "analyst" && <AnalystDashboard user={user} onLogout={handleLogout} />}
    </div>
  )
}
