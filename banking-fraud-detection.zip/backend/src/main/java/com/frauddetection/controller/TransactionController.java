package com.frauddetection.controller;

import com.frauddetection.dto.TransactionRequest;
import com.frauddetection.dto.TransactionResponse;
import com.frauddetection.model.Transaction;
import com.frauddetection.service.TransactionService;
import com.frauddetection.service.FraudDetectionService;
import com.frauddetection.service.BlockchainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@CrossOrigin(origins = "http://localhost:3000")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private FraudDetectionService fraudDetectionService;

    @Autowired
    private BlockchainService blockchainService;

    @GetMapping
    public ResponseEntity<List<Transaction>> getTransactions(
            @RequestParam(required = false) String userId,
            @RequestHeader("Authorization") String token) {
        
        List<Transaction> transactions = transactionService.getTransactionsByUser(userId);
        return ResponseEntity.ok(transactions);
    }

    @PostMapping
    public ResponseEntity<TransactionResponse> processTransaction(
            @RequestBody TransactionRequest request,
            @RequestHeader("Authorization") String token) {
        
        try {
            // 1. Create transaction
            Transaction transaction = transactionService.createTransaction(request);
            
            // 2. Run fraud detection ML algorithms
            double riskScore = fraudDetectionService.calculateRiskScore(transaction);
            transaction.setRiskScore(riskScore);
            
            // 3. Determine transaction status based on risk
            if (riskScore > 0.8) {
                transaction.setStatus("blocked");
            } else if (riskScore > 0.5) {
                transaction.setStatus("flagged");
            } else {
                transaction.setStatus("approved");
            }
            
            // 4. Log to blockchain
            String blockchainHash = blockchainService.logTransaction(transaction);
            transaction.setBlockchainHash(blockchainHash);
            
            // 5. Save to database
            Transaction savedTransaction = transactionService.saveTransaction(transaction);
            
            return ResponseEntity.ok(new TransactionResponse(true, "Transaction processed", savedTransaction));
            
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(new TransactionResponse(false, "Transaction processing failed", null));
        }
    }

    @GetMapping("/flagged")
    public ResponseEntity<List<Transaction>> getFlaggedTransactions(
            @RequestHeader("Authorization") String token) {
        
        List<Transaction> flaggedTransactions = transactionService.getFlaggedTransactions();
        return ResponseEntity.ok(flaggedTransactions);
    }

    @PutMapping("/{transactionId}/status")
    public ResponseEntity<String> updateTransactionStatus(
            @PathVariable String transactionId,
            @RequestParam String status,
            @RequestHeader("Authorization") String token) {
        
        transactionService.updateTransactionStatus(transactionId, status);
        return ResponseEntity.ok("Transaction status updated");
    }
}
