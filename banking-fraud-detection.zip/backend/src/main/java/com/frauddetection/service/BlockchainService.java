package com.frauddetection.service;

import com.frauddetection.model.Transaction;
import org.springframework.stereotype.Service;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.gas.DefaultGasProvider;

import java.math.BigInteger;
import java.security.MessageDigest;

@Service
public class BlockchainService {

    private Web3j web3j;
    private Credentials credentials;
    private String contractAddress;

    public BlockchainService() {
        // Initialize Web3j connection to blockchain network
        this.web3j = Web3j.build(new HttpService("http://localhost:8545")); // Ganache or other network
        // In production, load credentials securely
        this.contractAddress = "0xYourSmartContractAddress";
    }

    public String logTransaction(Transaction transaction) {
        try {
            // Create transaction hash
            String transactionData = transaction.getUserId() + 
                                   transaction.getAmount() + 
                                   transaction.getMerchant() + 
                                   transaction.getTimestamp();
            
            String hash = calculateHash(transactionData);
            
            // Log to smart contract
            // In real implementation, you would call your smart contract method
            // Example: fraudDetectionContract.logTransaction(hash, transaction.getRiskScore()).send();
            
            // For demo, return mock hash
            return "0x" + hash.substring(0, 32);
            
        } catch (Exception e) {
            throw new RuntimeException("Failed to log transaction to blockchain", e);
        }
    }

    public boolean verifyTransaction(String transactionHash) {
        try {
            // Verify transaction exists on blockchain
            // In real implementation, query the blockchain
            return true; // Mock verification
        } catch (Exception e) {
            return false;
        }
    }

    public String deployFraudDetectionContract() {
        try {
            // Deploy smart contract for fraud detection
            // Return contract address
            return "0xNewContractAddress";
        } catch (Exception e) {
            throw new RuntimeException("Failed to deploy contract", e);
        }
    }

    private String calculateHash(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Failed to calculate hash", e);
        }
    }
}
