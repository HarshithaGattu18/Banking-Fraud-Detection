package com.frauddetection.service;

import com.frauddetection.model.Transaction;
import com.frauddetection.model.FraudPattern;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class FraudDetectionService {

    @Autowired
    private MLModelService mlModelService;

    @Autowired
    private TransactionService transactionService;

    public double calculateRiskScore(Transaction transaction) {
        double riskScore = 0.0;
        
        // 1. Amount-based risk
        riskScore += calculateAmountRisk(transaction);
        
        // 2. Time-based risk
        riskScore += calculateTimeRisk(transaction);
        
        // 3. Location-based risk
        riskScore += calculateLocationRisk(transaction);
        
        // 4. Pattern-based risk
        riskScore += calculatePatternRisk(transaction);
        
        // 5. ML model prediction
        riskScore += mlModelService.predictFraudProbability(transaction);
        
        // Normalize to 0-1 range
        return Math.min(1.0, riskScore / 5.0);
    }

    private double calculateAmountRisk(Transaction transaction) {
        // High amounts are riskier
        double amount = transaction.getAmount();
        if (amount > 10000) return 0.9;
        if (amount > 5000) return 0.6;
        if (amount > 1000) return 0.3;
        return 0.1;
    }

    private double calculateTimeRisk(Transaction transaction) {
        // Transactions at unusual hours are riskier
        int hour = transaction.getTimestamp().getHour();
        if (hour >= 2 && hour <= 6) return 0.7; // Late night
        if (hour >= 22 || hour <= 1) return 0.4; // Very late/early
        return 0.1;
    }

    private double calculateLocationRisk(Transaction transaction) {
        // Check for unusual locations
        String location = transaction.getLocation();
        List<String> userLocations = transactionService.getUserRecentLocations(transaction.getUserId());
        
        if (!userLocations.contains(location)) {
            return 0.8; // New location
        }
        return 0.1;
    }

    private double calculatePatternRisk(Transaction transaction) {
        // Check for suspicious patterns
        List<Transaction> recentTransactions = transactionService.getRecentTransactions(
            transaction.getUserId(), 24); // Last 24 hours
        
        // Multiple high-value transactions
        long highValueCount = recentTransactions.stream()
            .filter(t -> t.getAmount() > 1000)
            .count();
        
        if (highValueCount > 3) return 0.9;
        if (highValueCount > 1) return 0.5;
        
        return 0.1;
    }

    public List<FraudPattern> detectPatterns() {
        // Analyze transaction data to identify new fraud patterns
        return mlModelService.identifyFraudPatterns();
    }
}
