"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CreditCard, AlertTriangle, Shield, LogOut, DollarSign, Activity } from "lucide-react"
import type { User } from "@/app/page"

interface Transaction {
  id: string
  amount: number
  merchant: string
  timestamp: string
  status: "normal" | "flagged" | "blocked"
  riskScore: number
}

interface UserDashboardProps {
  user: User
  onLogout: () => void
}

export function UserDashboard({ user, onLogout }: UserDashboardProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [alerts, setAlerts] = useState<number>(0)

  useEffect(() => {
    // Simulate fetching user transactions from Java backend
    const mockTransactions: Transaction[] = [
      {
        id: "1",
        amount: 250.0,
        merchant: "Amazon",
        timestamp: "2024-01-07 14:30",
        status: "normal",
        riskScore: 0.2,
      },
      {
        id: "2",
        amount: 1500.0,
        merchant: "Unknown Merchant",
        timestamp: "2024-01-07 02:15",
        status: "flagged",
        riskScore: 0.8,
      },
      {
        id: "3",
        amount: 50.0,
        merchant: "Starbucks",
        timestamp: "2024-01-06 09:45",
        status: "normal",
        riskScore: 0.1,
      },
    ]

    setTransactions(mockTransactions)
    setAlerts(mockTransactions.filter((t) => t.status === "flagged").length)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "normal":
        return "bg-green-500"
      case "flagged":
        return "bg-yellow-500"
      case "blocked":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Welcome, {user.username}</h1>
            <p className="text-gray-300">Transaction Dashboard</p>
          </div>
          <Button onClick={onLogout} variant="outline" className="text-white border-white/20 bg-transparent">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Total Balance</CardTitle>
              <DollarSign className="h-4 w-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">$12,450.00</div>
              <p className="text-xs text-gray-400">+2.5% from last month</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Transactions</CardTitle>
              <Activity className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{transactions.length}</div>
              <p className="text-xs text-gray-400">Last 7 days</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Fraud Alerts</CardTitle>
              <AlertTriangle className="h-4 w-4 text-yellow-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{alerts}</div>
              <p className="text-xs text-gray-400">Requires attention</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Security Score</CardTitle>
              <Shield className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">95%</div>
              <p className="text-xs text-gray-400">Excellent</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="transactions" className="space-y-6">
          <TabsList className="bg-white/10 backdrop-blur-lg border-white/20">
            <TabsTrigger value="transactions" className="text-white">
              Recent Transactions
            </TabsTrigger>
            <TabsTrigger value="alerts" className="text-white">
              Fraud Alerts
            </TabsTrigger>
            <TabsTrigger value="blockchain" className="text-white">
              Blockchain Logs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="transactions">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions.map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <CreditCard className="h-8 w-8 text-blue-400" />
                        <div>
                          <p className="text-white font-medium">{transaction.merchant}</p>
                          <p className="text-gray-400 text-sm">{transaction.timestamp}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <p className="text-white font-medium">${transaction.amount.toFixed(2)}</p>
                          <p className="text-gray-400 text-sm">Risk: {(transaction.riskScore * 100).toFixed(0)}%</p>
                        </div>
                        <Badge className={`${getStatusColor(transaction.status)} text-white`}>
                          {transaction.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Fraud Alerts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions
                    .filter((t) => t.status === "flagged")
                    .map((transaction) => (
                      <div
                        key={transaction.id}
                        className="flex items-center justify-between p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <AlertTriangle className="h-8 w-8 text-yellow-400" />
                          <div>
                            <p className="text-white font-medium">Suspicious Transaction Detected</p>
                            <p className="text-gray-400 text-sm">
                              {transaction.merchant} - ${transaction.amount.toFixed(2)}
                            </p>
                            <p className="text-gray-400 text-sm">{transaction.timestamp}</p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" className="text-white border-white/20 bg-transparent">
                            Review
                          </Button>
                          <Button size="sm" className="bg-red-500 hover:bg-red-600">
                            Block
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="blockchain">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Blockchain Transaction Logs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="h-3 w-3 bg-green-400 rounded-full"></div>
                      <div>
                        <p className="text-white font-medium">Transaction Verified on Blockchain</p>
                        <p className="text-gray-400 text-sm">Block Hash: 0x1a2b3c4d5e6f7890abcdef1234567890</p>
                        <p className="text-gray-400 text-sm">Timestamp: 2024-01-07 14:30:45</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="h-3 w-3 bg-blue-400 rounded-full"></div>
                      <div>
                        <p className="text-white font-medium">Smart Contract Executed</p>
                        <p className="text-gray-400 text-sm">Contract: FraudDetection.sol</p>
                        <p className="text-gray-400 text-sm">Gas Used: 21,000</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
