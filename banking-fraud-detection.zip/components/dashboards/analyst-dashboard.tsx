"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, Brain, LogOut, BarChart3, PieChart, Activity, Target } from "lucide-react"
import type { User } from "@/app/page"

interface MLModel {
  id: string
  name: string
  accuracy: number
  status: "training" | "deployed" | "testing"
  lastUpdated: string
}

interface FraudPattern {
  id: string
  pattern: string
  confidence: number
  occurrences: number
  riskLevel: "low" | "medium" | "high"
}

interface AnalystDashboardProps {
  user: User
  onLogout: () => void
}

export function AnalystDashboard({ user, onLogout }: AnalystDashboardProps) {
  const [mlModels, setMlModels] = useState<MLModel[]>([])
  const [fraudPatterns, setFraudPatterns] = useState<FraudPattern[]>([])
  const [analysisData, setAnalysisData] = useState({
    totalTransactions: 15420,
    fraudDetected: 127,
    falsePositives: 23,
    accuracy: 94.2,
  })

  useEffect(() => {
    // Mock data - in real app, fetch from Java backend ML service
    setMlModels([
      {
        id: "1",
        name: "Random Forest Classifier",
        accuracy: 94.2,
        status: "deployed",
        lastUpdated: "2024-01-07 10:30",
      },
      { id: "2", name: "Neural Network", accuracy: 96.8, status: "training", lastUpdated: "2024-01-07 08:15" },
      { id: "3", name: "SVM Classifier", accuracy: 91.5, status: "testing", lastUpdated: "2024-01-06 16:45" },
      { id: "4", name: "Gradient Boosting", accuracy: 93.7, status: "deployed", lastUpdated: "2024-01-06 14:20" },
    ])

    setFraudPatterns([
      {
        id: "1",
        pattern: "Multiple high-value transactions in short time",
        confidence: 0.89,
        occurrences: 15,
        riskLevel: "high",
      },
      { id: "2", pattern: "Unusual geographic location", confidence: 0.76, occurrences: 32, riskLevel: "medium" },
      { id: "3", pattern: "Off-hours transaction pattern", confidence: 0.65, occurrences: 28, riskLevel: "medium" },
      { id: "4", pattern: "New merchant with high amount", confidence: 0.92, occurrences: 8, riskLevel: "high" },
    ])
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "deployed":
        return "bg-green-500"
      case "training":
        return "bg-blue-500"
      case "testing":
        return "bg-yellow-500"
      default:
        return "bg-gray-500"
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "high":
        return "bg-red-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Fraud Analysis Panel</h1>
            <p className="text-gray-300">Machine Learning & Pattern Analysis</p>
          </div>
          <Button onClick={onLogout} variant="outline" className="text-white border-white/20 bg-transparent">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Model Accuracy</CardTitle>
              <Brain className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{analysisData.accuracy}%</div>
              <Progress value={analysisData.accuracy} className="mt-2" />
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Fraud Detected</CardTitle>
              <AlertTriangle className="h-4 w-4 text-red-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{analysisData.fraudDetected}</div>
              <p className="text-xs text-gray-400">Out of {analysisData.totalTransactions} transactions</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">False Positives</CardTitle>
              <Target className="h-4 w-4 text-yellow-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{analysisData.falsePositives}</div>
              <p className="text-xs text-gray-400">
                {((analysisData.falsePositives / analysisData.fraudDetected) * 100).toFixed(1)}% of detections
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Active Models</CardTitle>
              <Activity className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {mlModels.filter((m) => m.status === "deployed").length}
              </div>
              <p className="text-xs text-gray-400">Currently deployed</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="models" className="space-y-6">
          <TabsList className="bg-white/10 backdrop-blur-lg border-white/20">
            <TabsTrigger value="models" className="text-white">
              ML Models
            </TabsTrigger>
            <TabsTrigger value="patterns" className="text-white">
              Fraud Patterns
            </TabsTrigger>
            <TabsTrigger value="analytics" className="text-white">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="reports" className="text-white">
              Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="models">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Machine Learning Models</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mlModels.map((model) => (
                    <div key={model.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <Brain className="h-8 w-8 text-purple-400" />
                        <div>
                          <p className="text-white font-medium">{model.name}</p>
                          <p className="text-gray-400 text-sm">Accuracy: {model.accuracy}%</p>
                          <p className="text-gray-400 text-sm">Last updated: {model.lastUpdated}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <Progress value={model.accuracy} className="w-24 mb-2" />
                          <Badge className={`${getStatusColor(model.status)} text-white`}>{model.status}</Badge>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" className="text-white border-white/20 bg-transparent">
                            Configure
                          </Button>
                          {model.status === "deployed" ? (
                            <Button size="sm" variant="destructive">
                              Stop
                            </Button>
                          ) : (
                            <Button size="sm" className="bg-green-500 hover:bg-green-600">
                              Deploy
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="patterns">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Detected Fraud Patterns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {fraudPatterns.map((pattern) => (
                    <div key={pattern.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <AlertTriangle
                          className={`h-8 w-8 ${pattern.riskLevel === "high" ? "text-red-400" : pattern.riskLevel === "medium" ? "text-yellow-400" : "text-green-400"}`}
                        />
                        <div>
                          <p className="text-white font-medium">{pattern.pattern}</p>
                          <p className="text-gray-400 text-sm">Confidence: {(pattern.confidence * 100).toFixed(1)}%</p>
                          <p className="text-gray-400 text-sm">Occurrences: {pattern.occurrences}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <Progress value={pattern.confidence * 100} className="w-24 mb-2" />
                          <Badge className={`${getRiskColor(pattern.riskLevel)} text-white`}>
                            {pattern.riskLevel} risk
                          </Badge>
                        </div>
                        <Button size="sm" variant="outline" className="text-white border-white/20 bg-transparent">
                          Analyze
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-white/10 backdrop-blur-lg border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2" />
                    Detection Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-300">True Positives</span>
                        <span className="text-white">104</span>
                      </div>
                      <Progress value={82} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-300">False Positives</span>
                        <span className="text-white">23</span>
                      </div>
                      <Progress value={18} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-300">False Negatives</span>
                        <span className="text-white">8</span>
                      </div>
                      <Progress value={6} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-lg border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <PieChart className="h-5 w-5 mr-2" />
                    Risk Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <span className="text-gray-300">High Risk</span>
                      </div>
                      <span className="text-white">15%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <span className="text-gray-300">Medium Risk</span>
                      </div>
                      <span className="text-white">25%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-gray-300">Low Risk</span>
                      </div>
                      <span className="text-white">60%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="reports">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Analysis Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-white font-semibold">Weekly Fraud Analysis Report</h3>
                        <p className="text-gray-400 text-sm">Generated on 2024-01-07</p>
                        <p className="text-gray-400 text-sm">127 fraud cases detected, 94.2% accuracy</p>
                      </div>
                      <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                        Download
                      </Button>
                    </div>
                  </div>

                  <div className="p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-white font-semibold">Model Performance Comparison</h3>
                        <p className="text-gray-400 text-sm">Generated on 2024-01-06</p>
                        <p className="text-gray-400 text-sm">Comparative analysis of 4 ML models</p>
                      </div>
                      <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                        Download
                      </Button>
                    </div>
                  </div>

                  <div className="p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-white font-semibold">Pattern Analysis Summary</h3>
                        <p className="text-gray-400 text-sm">Generated on 2024-01-05</p>
                        <p className="text-gray-400 text-sm">Identified 12 new fraud patterns</p>
                      </div>
                      <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                        Download
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
