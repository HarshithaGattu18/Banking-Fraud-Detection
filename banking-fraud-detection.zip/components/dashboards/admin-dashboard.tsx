"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Users, AlertTriangle, Shield, LogOut, BarChart3, Database, Search } from "lucide-react"
import type { User } from "@/app/page"

interface SystemUser {
  id: string
  username: string
  role: string
  status: "active" | "suspended" | "pending"
  lastLogin: string
}

interface FlaggedTransaction {
  id: string
  userId: string
  amount: number
  merchant: string
  riskScore: number
  timestamp: string
  status: "pending" | "approved" | "blocked"
}

interface AdminDashboardProps {
  user: User
  onLogout: () => void
}

export function AdminDashboard({ user, onLogout }: AdminDashboardProps) {
  const [users, setUsers] = useState<SystemUser[]>([])
  const [flaggedTransactions, setFlaggedTransactions] = useState<FlaggedTransaction[]>([])
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    // Mock data - in real app, fetch from Java backend
    setUsers([
      { id: "1", username: "john_doe", role: "user", status: "active", lastLogin: "2024-01-07 10:30" },
      { id: "2", username: "jane_smith", role: "user", status: "active", lastLogin: "2024-01-06 15:45" },
      { id: "3", username: "analyst_mike", role: "analyst", status: "active", lastLogin: "2024-01-07 09:15" },
      { id: "4", username: "suspicious_user", role: "user", status: "suspended", lastLogin: "2024-01-05 22:30" },
    ])

    setFlaggedTransactions([
      {
        id: "1",
        userId: "john_doe",
        amount: 5000,
        merchant: "Unknown ATM",
        riskScore: 0.9,
        timestamp: "2024-01-07 02:15",
        status: "pending",
      },
      {
        id: "2",
        userId: "jane_smith",
        amount: 2500,
        merchant: "Overseas Transfer",
        riskScore: 0.7,
        timestamp: "2024-01-06 23:45",
        status: "pending",
      },
      {
        id: "3",
        userId: "suspicious_user",
        amount: 10000,
        merchant: "Crypto Exchange",
        riskScore: 0.95,
        timestamp: "2024-01-05 20:30",
        status: "blocked",
      },
    ])
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500"
      case "suspended":
        return "bg-red-500"
      case "pending":
        return "bg-yellow-500"
      case "approved":
        return "bg-blue-500"
      case "blocked":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const handleTransactionAction = (transactionId: string, action: "approve" | "block") => {
    setFlaggedTransactions((prev) =>
      prev.map((t) => (t.id === transactionId ? { ...t, status: action === "approve" ? "approved" : "blocked" } : t)),
    )
  }

  const handleUserAction = (userId: string, action: "suspend" | "activate") => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: action === "suspend" ? "suspended" : "active" } : u)),
    )
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Admin Control Panel</h1>
            <p className="text-gray-300">System Management & Monitoring</p>
          </div>
          <Button onClick={onLogout} variant="outline" className="text-white border-white/20 bg-transparent">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Total Users</CardTitle>
              <Users className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{users.length}</div>
              <p className="text-xs text-gray-400">Active: {users.filter((u) => u.status === "active").length}</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Flagged Transactions</CardTitle>
              <AlertTriangle className="h-4 w-4 text-yellow-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {flaggedTransactions.filter((t) => t.status === "pending").length}
              </div>
              <p className="text-xs text-gray-400">Pending review</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">System Health</CardTitle>
              <Shield className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">98%</div>
              <p className="text-xs text-gray-400">All systems operational</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Blockchain Nodes</CardTitle>
              <Database className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">12</div>
              <p className="text-xs text-gray-400">Connected nodes</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="bg-white/10 backdrop-blur-lg border-white/20">
            <TabsTrigger value="users" className="text-white">
              User Management
            </TabsTrigger>
            <TabsTrigger value="transactions" className="text-white">
              Flagged Transactions
            </TabsTrigger>
            <TabsTrigger value="reports" className="text-white">
              System Reports
            </TabsTrigger>
            <TabsTrigger value="blockchain" className="text-white">
              Blockchain Logs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-white">User Management</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Search className="h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search users..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-64 bg-white/10 border-white/20 text-white"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users
                    .filter((user) => user.username.toLowerCase().includes(searchTerm.toLowerCase()))
                    .map((systemUser) => (
                      <div key={systemUser.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <Users className="h-8 w-8 text-blue-400" />
                          <div>
                            <p className="text-white font-medium">{systemUser.username}</p>
                            <p className="text-gray-400 text-sm">Role: {systemUser.role}</p>
                            <p className="text-gray-400 text-sm">Last login: {systemUser.lastLogin}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <Badge className={`${getStatusColor(systemUser.status)} text-white`}>
                            {systemUser.status}
                          </Badge>
                          <div className="flex space-x-2">
                            {systemUser.status === "active" ? (
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleUserAction(systemUser.id, "suspend")}
                              >
                                Suspend
                              </Button>
                            ) : (
                              <Button
                                size="sm"
                                className="bg-green-500 hover:bg-green-600"
                                onClick={() => handleUserAction(systemUser.id, "activate")}
                              >
                                Activate
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="transactions">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Flagged Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {flaggedTransactions.map((transaction) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-4 bg-red-500/10 border border-red-500/20 rounded-lg"
                    >
                      <div className="flex items-center space-x-4">
                        <AlertTriangle className="h-8 w-8 text-red-400" />
                        <div>
                          <p className="text-white font-medium">High Risk Transaction</p>
                          <p className="text-gray-400 text-sm">User: {transaction.userId}</p>
                          <p className="text-gray-400 text-sm">
                            {transaction.merchant} - ${transaction.amount.toFixed(2)}
                          </p>
                          <p className="text-gray-400 text-sm">
                            Risk Score: {(transaction.riskScore * 100).toFixed(0)}%
                          </p>
                          <p className="text-gray-400 text-sm">{transaction.timestamp}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <Badge className={`${getStatusColor(transaction.status)} text-white`}>
                          {transaction.status}
                        </Badge>
                        {transaction.status === "pending" && (
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              className="bg-green-500 hover:bg-green-600"
                              onClick={() => handleTransactionAction(transaction.id, "approve")}
                            >
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleTransactionAction(transaction.id, "block")}
                            >
                              Block
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">System Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="p-6 bg-white/5 rounded-lg">
                    <div className="flex items-center space-x-4 mb-4">
                      <BarChart3 className="h-8 w-8 text-blue-400" />
                      <div>
                        <h3 className="text-white font-semibold">Fraud Detection Rate</h3>
                        <p className="text-gray-400 text-sm">Last 30 days</p>
                      </div>
                    </div>
                    <div className="text-3xl font-bold text-white mb-2">94.5%</div>
                    <p className="text-green-400 text-sm">↑ 2.3% from last month</p>
                  </div>

                  <div className="p-6 bg-white/5 rounded-lg">
                    <div className="flex items-center space-x-4 mb-4">
                      <Shield className="h-8 w-8 text-green-400" />
                      <div>
                        <h3 className="text-white font-semibold">False Positive Rate</h3>
                        <p className="text-gray-400 text-sm">Last 30 days</p>
                      </div>
                    </div>
                    <div className="text-3xl font-bold text-white mb-2">2.1%</div>
                    <p className="text-green-400 text-sm">↓ 0.5% from last month</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="blockchain">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Blockchain Network Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="h-3 w-3 bg-green-400 rounded-full"></div>
                        <div>
                          <p className="text-white font-medium">Network Status: Online</p>
                          <p className="text-gray-400 text-sm">12 nodes connected</p>
                        </div>
                      </div>
                      <Badge className="bg-green-500 text-white">Healthy</Badge>
                    </div>
                  </div>

                  <div className="p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="h-3 w-3 bg-blue-400 rounded-full"></div>
                        <div>
                          <p className="text-white font-medium">Latest Block: #1,234,567</p>
                          <p className="text-gray-400 text-sm">Hash: 0x1a2b3c4d5e6f7890...</p>
                        </div>
                      </div>
                      <Badge className="bg-blue-500 text-white">Confirmed</Badge>
                    </div>
                  </div>

                  <div className="p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="h-3 w-3 bg-purple-400 rounded-full"></div>
                        <div>
                          <p className="text-white font-medium">Smart Contracts: 5 Active</p>
                          <p className="text-gray-400 text-sm">FraudDetection.sol, UserAuth.sol, TransactionLog.sol</p>
                        </div>
                      </div>
                      <Badge className="bg-purple-500 text-white">Deployed</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
